﻿var winX;
var isToolTipOpen = 0;
var OldtoolTipId;
var p = 0;
var bottomHead;
var fewSec;

$(document).ready(function () {
    document.getElementById("defaultOpen").click(); //לוחץ על הטאב עם האי די הזה
    ieVersionMain();
    //document.addEventListener('contextmenu', event => event.preventDefault());

    winX = window.outerWidth;

    bottomHead = $('.tab').position().top + $('.tab').outerHeight(true);

    SizeEventListener();
    
    $('body').on('click', 'img', function (event) {
        
        var familyValue = event.currentTarget.getAttribute("family");
        console.log(familyValue);
        if (familyValue != null)
        EmojiClick(event);
    })
});

function ieVersion() {
    //בודק את גירסת האינטרנט אקספלורר של המשתמש

    var ua = window.navigator.userAgent;
    //var VerNum;
    if (ua.indexOf("Trident/7.0") > -1) {
        return 11;
    }
    else if (ua.indexOf("Trident/6.0") > -1)
        return 10;
    else if (ua.indexOf("Trident/5.0") > -1)
        return 9;
    else
        return 0;  // not IE9, 10 or 11

}

function ieVersionMain() {
    var VerNum = ieVersion();

    if (VerNum != 11)
        document.getElementById("NoReDot").style.display = "inline-block";
}

function ieVersionMore(fewSec) {

    setTimeout(function () {
        fewSec = -1;
        if (fewSec == -1) {

    var VerNum = ieVersion();
    var getIEtxt = "<br /> for best result download Internet Explorer 11.";
    var tags = "<div id='foredot'><span class='redot'></span></div>";

    if (VerNum == 11) {
        document.getElementById("ieVer").style.display = "none";
    }
    else if (VerNum == 10 || VerNum == 9) {
        document.getElementById("ieVer").style.display = "block";
        document.getElementById("ieVer").innerHTML = tags + "You are using Internet Explorer " + VerNum.toString() + ".<br />" + getIEtxt;
    }
    else if (VerNum == 0) {
        document.getElementById("ieVer").style.display = "block";
        document.getElementById("ieVer").innerHTML = tags + "You are using an older version of Internet Explorer." + "<br />" + getIEtxt;
    }

        }
    }, 1300);
}


function ieVersionOriginal() {
    //בודק את גירסת האינטרנט אקספלורר של המשתמש
    
    var ua = window.navigator.userAgent;
    var VerNum;
    if (ua.indexOf("Trident/7.0") > -1) {
        VerNum = 11;
    }
    else if (ua.indexOf("Trident/6.0") > -1)
        VerNum = 10;
    else if (ua.indexOf("Trident/5.0") > -1)
        VerNum = 9;
    else
        VerNum = 0;  // not IE9, 10 or 11


    var reddotspan = "<div id='foredot'><span class='redot'></span></div>"

    if (VerNum == 11) {
        document.getElementById("ieVer").style.display = "none";
    }
    else if (VerNum == 10 || VerNum == 9){
        document.getElementById("ieVer").innerHTML +=   "You are using Internet Explorer " + VerNum.toString() + ".<br />" + getIEtxt;
        document.getElementById("NoReDot").style.display = "inline-block";
    }
    else if (VerNum == 0) {
        document.getElementById("ieVer").innerHTML += "You are using an older version of Internet Explorer." + "<br />" + getIEtxt;
        document.getElementById("NoReDot").style.display = "inline-block";
        var bla = 1;
    }

}


function closeload() {
    $("#loadDiv").hide(1000);
}

function pluseOne(p) {
    p++;
    document.getElementById("emojiCounter").innerHTML = p;
    if (p > 2375) {
        $("#spinImg").css("animation-name", "none");
        setTimeout(function () { $("#loadDiv").hide(1000); clearTimeout(); }, 2000);
    }
}


function SizeEventListener() {
    //לסמן את כפתור הגודל כפעיל
    var btnContainer = document.getElementById("header");
    var btns = btnContainer.getElementsByClassName("EmojiSizeC");
    // Loop through the buttons and add the active class to the current/clicked button
    for (var i = 0; i < btns.length; i++) {
        btns[i].addEventListener("click", function () {
            var current = document.getElementsByClassName("active");
            current[0].className = current[0].className.replace(" active", "");
            this.className += " active";
        });
    }
}



function EmojiClick(event) { //לחיצה על אימוג'י
   // console.log("event2: " + event);
    event = event || window.event;

    var idValue = event.currentTarget.id;
    var altValue = event.currentTarget.alt;
    var familyValue = event.currentTarget.getAttribute("family");
    var posIdX = document.getElementById(idValue);
    toolTipId = document.getElementById("tl_" + familyValue);

    //document.getElementById("forTests").innerHTML = idValue; //כותב את האי די בעמוד לצורך בדיקות

    if (familyValue != OldtoolTipId && isToolTipOpen == 1) {
        var ClassOldtoolTipId = document.getElementById("tl_" + OldtoolTipId);
        ClassOldtoolTipId.className = ClassOldtoolTipId.className.replace("tooltiptext vis", "tooltiptext");
        isToolTipOpen = 0;
    }

    if (toolTipId == null) {
        document.title = idValue; //מעביר את שם האימוגי לכותרת
        //EmojiToUpdate[idValue] = EmojiToUpdate[idValue] + 1;
    }
    else { //אם לא נל אז צריך להראות את הטול טיפ

        var perPageX = (event.pageX / winX);
        //console.log("perPageX: " + perPageX);
        //console.log("winX: " + winX + " | pageX.x: " + event.pageX + " | sum: " + (winX - event.pageX));

        //מיקום הטול טיפ כאשר יוצג
        toolTipId.removeAttribute("style");

        if (perPageX > 0.65)
            toolTipId.style.right = "0px";
        else if (perPageX > 0.35)
            toolTipId.style.left = "-145%";
        else if (perPageX < 0.65)
            toolTipId.style.left = "48px";

        
        //הוספת קלאס לצורך הצגת הטול טיפ
        if (toolTipId.className == "tooltiptext") {
            toolTipId.className = toolTipId.className.replace("tooltiptext", "tooltiptext vis");
            isToolTipOpen = 1;
            OldtoolTipId = familyValue;

            var TooltipTop = $('.vis').offset().top;
            if (TooltipTop < bottomHead) //אם הטולטיפ גבוה מהכותרת אז תוריד אותו למטה
                $(".tooltiptext").css("bottom", '-106%');
            

        }
        else if (toolTipId.className == "tooltiptext vis") {
            toolTipId.className = toolTipId.className.replace("tooltiptext vis", "tooltiptext");
            document.title = idValue;
            isToolTipOpen = 0;
            OldtoolTipId = "someValue";
        }

    }

    
    

}



function EmojiSize(event){ //גודל האימוג'י
	var varEmojiSize = event.currentTarget.getAttribute("ImgSize");
	document.getElementById("ImgSizeID").innerHTML = varEmojiSize;

    //לסמן את כפתור הגודל כפעיל
	SizeEventListener();
}

function openTab(evt, TabName) { //עבור הטאבים
    var i, tabcontent, tablinks;

    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }

    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }

    document.getElementById(TabName).style.display = "block";
    evt.currentTarget.className += " active";
}